extends Node

func _ready():
	$/root/SceneManager/global.betamode = true
