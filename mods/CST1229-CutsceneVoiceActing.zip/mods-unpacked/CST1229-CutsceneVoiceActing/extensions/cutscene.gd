extends "res://cutscene.gd"

var raw_text: String = "";

var voiced_letters = {
	"barfbot": {
		a = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/a.wav"),
		b = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/b.wav"),
		c = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/c.wav"),
		d = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/d.wav"),
		e = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/e.wav"),
		f = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/f.wav"),
		g = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/g.wav"),
		h = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/h.wav"),
		i = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/i.wav"),
		j = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/j.wav"),
		k = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/k.wav"),
		l = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/l.wav"),
		m = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/m.wav"),
		n = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/n.wav"),
		o = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/o.wav"),
		p = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/p.wav"),
		q = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/q.wav"),
		r = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/r.wav"),
		s = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/s.wav"),
		t = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/t.wav"),
		u = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/u.wav"),
		v = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/v.wav"),
		w = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/w.wav"),
		x = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/x.wav"),
		y = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/y.wav"),
		z = load("res://mods-unpacked/CST1229-CutsceneVoiceActing/voices/barfbot/z.wav"),
	}
};
var current_voice := "barfbot";
var voice_pitch = 1.0;
var stream_players := [];
const MAX_STREAM_PLAYERS = 2;

func _ready() -> void :
	super();
	$Timer.wait_time = 0.06;
	
func next_dialogue():
	current_voice = "barfbot";
	super();
	voice_pitch = 1.0;
	match ($UI / DialogueBox / Name).text.to_lower():
		"barfy":
			voice_pitch = 1.15;
		"waiter am i":
			voice_pitch = 0.9;
	raw_text = $UI / DialogueBox / Text.get_parsed_text();

func _on_timer_timeout() -> void :
	if playing_line == true:
		if $UI / DialogueBox / Text.visible_ratio < 1:
			$Voice.pitch_scale = randf_range(0.9, 1.1)
			$UI / DialogueBox / Text.visible_characters += 1
			# $Voice.play()
			var current_char := raw_text[$UI / DialogueBox / Text.visible_characters - 1].to_lower();
			if current_voice in voiced_letters:
				if current_char in voiced_letters[current_voice]:
					var sound = voiced_letters[current_voice][current_char];
					var stream_player := AudioStreamPlayer.new();
					
					stream_players.append(stream_player);
					while stream_players.size() > MAX_STREAM_PLAYERS:
						if is_instance_valid(stream_players[0]):
							stream_players[0].queue_free();
						stream_players.remove_at(0);
					
					stream_player.bus = &"SFX";
					stream_player.stream = sound;
					stream_player.finished.connect(stream_player.queue_free);
					stream_player.volume_db = -3;
					stream_player.pitch_scale = voice_pitch;
					add_child(stream_player);
					stream_player.play();
			if current_char == " ":
				$Timer.wait_time = 0.1;
			elif current_char in [",", ".", "!", "?"]:
				$Timer.wait_time = 0.2;
			elif current_char in ["a", "e", "i", "o", "u"]:
				$Timer.wait_time = 0.08;
			else:
				$Timer.wait_time = 0.03;
			$Timer.start()
		else:
			playing_line = false
