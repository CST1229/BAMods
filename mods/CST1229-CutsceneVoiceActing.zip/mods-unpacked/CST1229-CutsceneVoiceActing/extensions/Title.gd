extends "res://Title.gd"

func _physics_process(delta):
	if Input.is_action_just_pressed("click"):
		if $Logo / Click.button_pressed and cutscene == false and playedcutscene == false:
			if logoclicks >= 10:
				playedcutscene = true
				cutscene = true
				global.cutscene = -1
				var b = load("res://CutsceneLevel.tscn").instantiate()
				b.add_to_group("title")
				add_child(b)
				$Cutscene.visible = true
				$Cutscene.reload_cutscene()
	super(delta);
