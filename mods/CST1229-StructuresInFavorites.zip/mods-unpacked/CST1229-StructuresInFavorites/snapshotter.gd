extends Viewport

@onready var node: Node2D = $Node
@onready var camera_2d: Camera2D = $Node/Camera2D

func take_snapshot() -> Image:
	var rect := _calculate_scene_rect(node, Rect2(0, 0, 0, 0));
	camera_2d.position = rect.get_center();
	var zoom := 128.0 / maxf(rect.size.x, rect.size.y);
	camera_2d.zoom = Vector2(zoom, zoom);
	print(camera_2d.zoom, camera_2d.position, rect.size, rect.get_center(), rect.position);
	await get_tree().process_frame;
	await get_tree().physics_frame;
	return get_texture().get_image();

# ported from https://github.com/godotengine/godot/pull/102313/files
func _calculate_scene_rect(p_node: Node, r_rect: Rect2) -> Rect2:
	# NOTE: There's no universal way to get the exact global rect as a Node2D, so we dig into subclasses one by one

	# NOTE:
	# 1. Sprite2D::position by default is at the **center** of the sprite. (with offset == (0,0) AND centered == true)
	# 2. Rect2::position is at the **up-left** of the rect
	# 3. AABB::position is at the **bottom-left-forward** of the bounding box
	#
	# calculation below is done with these in mind.

	var n2d_rect: Rect2; # The rect of the current iterating Node2D

	var sprite: Sprite2D = p_node as Sprite2D;
	if (sprite && sprite.is_visible_in_tree()):
		n2d_rect.size = sprite.global_scale * sprite.get_rect().size;
		n2d_rect.position = sprite.global_position + sprite.offset * sprite.global_scale;
		if (sprite.is_centered()):
			n2d_rect.position -= n2d_rect.size / 2.0;
		
	

	var anim_sprite: AnimatedSprite2D = p_node as AnimatedSprite2D;
	if (anim_sprite && anim_sprite.is_visible_in_tree()):
		if (anim_sprite.sprite_frames):
			var current_frame_tex: Texture2D = anim_sprite.sprite_frames.get_frame_texture(anim_sprite.animation, anim_sprite.frame);

			if (current_frame_tex):
				n2d_rect.size = current_frame_tex.size * anim_sprite.global_scale;
				n2d_rect.position = anim_sprite.global_position + anim_sprite.offset * anim_sprite.global_scale;
				if (anim_sprite.is_centered()):
					n2d_rect.position -= n2d_rect.size / 2.0;

	var mesh2d: MeshInstance2D = p_node as MeshInstance2D;
	if (mesh2d && mesh2d.is_visible_in_tree()):
		# NOTE: Conversion is 1m = 1px (before 2d scale)
		var mesh: Mesh = mesh2d.mesh;

		if (mesh):
			# Discard z axis (depth) and only get length of mesh in x,y axis
			n2d_rect.size.x = (mesh.get_aabb().end - mesh.get_aabb().position).x;
			n2d_rect.size.y = (mesh.get_aabb().end - mesh.get_aabb().position).y;
			n2d_rect.size *= mesh2d.global_scale;

			# Account for mesh offset in 3d space when calculating rect2
			n2d_rect.position.x = mesh2d.global_position.x + mesh.get_aabb().position.x * mesh2d.global_scale.x; # AABB::position is bottom-left
			n2d_rect.position.y = mesh2d.global_position.y + mesh.get_aabb().position.y * mesh2d.global_scale.y;
		
	

	var mmesh2d = p_node as MultiMeshInstance2D;
	if (mmesh2d && mmesh2d.is_visible_in_tree()):
		# Basically the same procedure as MeshInstance2D.
		var mmesh: MultiMesh = mmesh2d.get_multimesh();

		if (mmesh):
			n2d_rect.size.x = (mmesh.get_aabb().end - mmesh.get_aabb().position).x;
			n2d_rect.size.y = (mmesh.get_aabb().end - mmesh.get_aabb().position).y;
			n2d_rect.size *= mmesh2d.global_scale;

			n2d_rect.position.x = mmesh2d.global_position.x + mmesh.get_aabb().position.x * mmesh2d.global_scale.x;
			n2d_rect.position.y = mmesh2d.global_position.y + mmesh.get_aabb().position.y * mmesh2d.global_scale.y;
		
	
	var old_tile_map: TileMap = p_node as TileMap;
	if (old_tile_map && old_tile_map.is_visible_in_tree()):
		# NOTE: TileMapLayer::get_used_rect() only count cells, not their actual pixel size

		if (old_tile_map.tile_set):
			var tile_size: Vector2 = old_tile_map.tile_set.tile_size; # Tile map cell pixel size (x,y).
			var tile_rect: Rect2 = old_tile_map.get_used_rect(); # Unit is in cells, not pixels!

			n2d_rect.position = old_tile_map.global_position + tile_rect.position * tile_size * old_tile_map.global_scale; # Accounts tilemap offset
			n2d_rect.size = tile_rect.size * tile_size * old_tile_map.global_scale;

	var poly2d: Polygon2D = p_node as Polygon2D;
	if (poly2d && poly2d.is_visible_in_tree()):
		var polygon: PackedVector2Array = poly2d.polygon;

		if (polygon.size() > 2): # Abort if there's no surface (min = 3 verts)
			# Calculate bounds
			var max_x: float = polygon[0].x;
			var min_x: float = polygon[0].x;
			var max_y: float = polygon[0].y;
			var min_y: float = polygon[0].y;
			for i in polygon.size():
				if (polygon[i].x > max_x):
					max_x = polygon[i].x;
				if (polygon[i].x < min_x):
					min_x = polygon[i].x;
				
				if (polygon[i].y > max_y):
					max_y = polygon[i].y;
				if (polygon[i].y < min_y):
					min_y = polygon[i].y;
				
			

			var poly_rect: Rect2 = Rect2(min_x, min_y, max_x - min_x, max_y - min_y);

			n2d_rect.position = poly2d.global_position + poly2d.offset * poly2d.global_scale;
			n2d_rect.position += poly_rect.position * poly2d.global_scale;
			n2d_rect.size = poly_rect.size * poly2d.global_scale;
		
	

	var line2d: Line2D = p_node as Line2D;
	if (line2d && line2d.is_visible_in_tree()):
		# The same procedure as Polygon2D
		var points: PackedVector2Array = line2d.points;

		if (line2d.get_point_count() > 1): # Abort if there's no line drawn
			# Calculate bounds
			var max_x: float = points[0].x;
			var min_x: float = points[0].x;
			var max_y: float = points[0].y;
			var min_y: float = points[0].y;
			for i in points.size():
				if (points[i].x > max_x):
					max_x = points[i].x;
				if (points[i].x < min_x):
					min_x = points[i].x;

				if (points[i].y > max_y):
					max_y = points[i].y;
				
				if (points[i].y < min_y):
					min_y = points[i].y;
				
			

			var line2d_rect: Rect2 = Rect2(min_x, min_y, max_x - min_x, max_y - min_y);

			n2d_rect.position = line2d.global_position;
			n2d_rect.position += line2d_rect.position * line2d.global_scale;
			n2d_rect.size = line2d_rect.size * line2d.global_scale;
			n2d_rect.size += Vector2(line2d.width, line2d.width) / 2.0; # account for line width
		
	

	var btn: TouchScreenButton = p_node as TouchScreenButton;
	if (btn && btn.is_visible_in_tree()):
		var btn_tex: Texture2D = btn.texture_normal;

		if (btn_tex): # Abort if there's no normal texture for this button (won't display anything)
			n2d_rect.position = btn.global_position; # It's not possible to offset image in this node
			n2d_rect.size = btn_tex.size * btn.global_scale;
		
	

	# Merge the calculated node 2d rect
	if (r_rect.size.length_squared() == 0.0): # Avoid accounting scene origin (0,0) into scene rect.
		r_rect = n2d_rect.abs();
	else:
		r_rect = r_rect.merge(n2d_rect.abs());
		
	for node in p_node.get_children():
		r_rect = _calculate_scene_rect(node, r_rect);
	return r_rect;
