extends "res://Editor.gd"

func _physics_process(delta: float) -> void:
	if Input.is_action_just_pressed("click"):
		if !Input.is_action_pressed("ctrl"):
			for i in $Camera2D / CanvasLayer / CustomBar / Objects.get_children():
				if i.button_pressed && i.sif_structure:
					$"Sounds/RectangleFinish".play()
					for l in $CopyLayer.get_children():
						for t in l.get_used_cells(0):
							l.set_cell(0, t, -1)
					var content = i.sif_structure;
					if !content.has("Camera2"):
						content["Camera2"] = ""
					if !content.has("Camera3"):
						content["Camera3"] = ""
					if !content.has("Camera4"):
						content["Camera4"] = ""
					if !content.has("Key"):
						content["Key"] = ""
					if !content.has("Engine"):
						content["Engine"] = ""
					if !content.has("Guide"):
						content["Guide"] = ""
					var lib = get_node_or_null("/root/ModLoader/CST1229-BALib");
					if lib:
						lib.convert_loaded_leveldata($CopyLayer, content);
					for l in $CopyLayer.get_children():
						var tilearray = []
						if l.name != "Temp" && l.name in content:
							for t in content[str(l.name)].split("/"):
								var currenttile = t.split(",")
								if currenttile.size() == 5:

									l.set_cell(0, Vector2i(int(currenttile[1]), int(currenttile[2])), int(currenttile[0]), Vector2i(int(currenttile[3]), 0), global.rotations[int(currenttile[4])])
									tilearray.append(Vector2i(int(currenttile[1]), int(currenttile[2])))
							if tilearray.size() > 0:
								BetterTerrain.update_terrain_cells(l, 0, tilearray)
					pasted_from_structure = true
					favorite_drag_timer = 10
					dragging_favorite = false
					saved_favorite_hold_node = i
					holding_favorite = true
					favorite_dragged = i.sif_arr
					original_fdpos = i.pos
					update_preview()
					return
		elif infavorites && $Camera2D / CanvasLayer / Tools / paste.button_pressed:
			var structuredata = {};
			structuredata["TileMap"] = ""
			structuredata["Decoration"] = ""
			structuredata["Wall"] = ""
			structuredata["Camera"] = ""
			structuredata["Camera2"] = ""
			structuredata["Camera3"] = ""
			structuredata["Camera4"] = ""
			structuredata["Key"] = ""
			structuredata["Engine"] = ""
			structuredata["Guide"] = ""
			var has_tiles = false;
			for l in $"CopyLayer".get_children():
				for t in l.get_used_cells(0):
					structuredata[str(l.name)] = str(structuredata[str(l.name)], l.get_cell_source_id(0, t), ",", t.x, ",", t.y, ",", l.get_cell_atlas_coords(0, t).x, ",", global.rotations.find(l.get_cell_alternative_tile(0, t)), "/")
					has_tiles = true;
			if !has_tiles:
				global.notify.emit("No tiles selected");
				return;
			dragging_favorite = false
			
			var snapshotter = load("res://mods-unpacked/CST1229-StructuresInFavorites/Snapshotter.tscn").instantiate();
			add_child(snapshotter);
			var copied_layer = $CopyLayer.duplicate(0);
			copied_layer.visible = true;
			copied_layer.modulate = Color.WHITE;
			copied_layer.global_transform = Transform2D();
			snapshotter.node.add_child(copied_layer);
			var image = await snapshotter.take_snapshot();
			#var image = get_viewport().get_texture().get_image();
			global.favorites[favorite_category].append(
				[25, 0, {sif_structure = structuredata, sif_thumbnail = image.save_png_to_buffer()}]
			);

			snapshotter.queue_free();
			
			$Sounds / MoveFavorite.pitch_scale = randf_range(0.8, 1.2)
			$Sounds / MoveFavorite.play()
			save_favorites()
			refresh_favorites()
			return;
	var last_dragged = dragging_favorite;
	super(delta);
	if dragging_favorite && favorite_dragged.size() > 2 && favorite_dragged[-1] is Dictionary && "sif_structure" in favorite_dragged[-1]:
		if !last_dragged:
			$Camera2D / CanvasLayer / DraggedObject.scale /= 2.0;
		$Camera2D / CanvasLayer / DraggedObject.offset *= 4.0;
		$Camera2D / CanvasLayer / DraggedObject.texture = saved_favorite_hold_node.texture_normal;
		$Camera2D / CanvasLayer / DraggedObject.scale = lerp($Camera2D / CanvasLayer / DraggedObject.scale, Vector2(-2.1, -2.1), 0.2)
	
var sif_editor_obj = ResourceLoader.load("res://EditorObject.tscn", "", ResourceLoader.CACHE_MODE_REPLACE_DEEP);
func refresh_favorites():
	if infavorites:
		sif_editor_obj = ResourceLoader.load("res://EditorObject.tscn", "", ResourceLoader.CACHE_MODE_REPLACE_DEEP);
	
	$Camera2D / CanvasLayer / CustomBar.visible = infavorites
	$Camera2D / CanvasLayer / ScrollContainer.visible = !infavorites
	for i in $Camera2D / CanvasLayer / CustomBar / Objects.get_children():
		i.queue_free()
	if !infavorites:
		return;
	var favcount = 0
	for i in global.favorites[favorite_category]:
		var b = sif_editor_obj.instantiate()
		b.id = i[0]
		b.title = ""
		b.color = i[1]
		b.name = str(i[0], "-", i[1])
		b.pos = favcount
		b.sif_arr = i;
		favcount += 1
		$Camera2D / CanvasLayer / CustomBar / Objects.add_child(b)
		b.sif_ready();

func update_preview():
	if favorite_dragged && is_instance_valid(saved_favorite_hold_node) && !saved_favorite_hold_node.is_queued_for_deletion() && saved_favorite_hold_node.get("sif_arr"):
		favorite_dragged = saved_favorite_hold_node.sif_arr;
	super();
