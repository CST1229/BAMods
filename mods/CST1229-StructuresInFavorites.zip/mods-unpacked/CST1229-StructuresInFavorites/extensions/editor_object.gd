extends "res://editor_object.gd"

var sif_arr = null;
var sif_structure = null;

func sif_ready():
	var arr = sif_arr;
	if !arr || arr.size() <= 2 || arr[-1] is not Dictionary || arr[-1].get("sif_structure") is not Dictionary:
		return;
	sif_structure = sif_arr[-1].get("sif_structure");
	if arr[-1].get("sif_thumbnail") is PackedByteArray:
		var img := Image.create_empty(1, 1, false, Image.FORMAT_RGBA8);
		var err := img.load_png_from_buffer(arr[-1]["sif_thumbnail"]);
		if err:
			global.notify.emit("Could not load structure thumbnail:\n" + error_string(err));
		else:
			texture_normal = ImageTexture.create_from_image(img);
