extends Node


const MOD_DIR := "CST1229-BADimensions"
const LOG_NAME := "CST1229-BADimensions:Main"

var mod_dir_path := ""
var extensions_dir_path := ""
var translations_dir_path := ""


func _init() -> void:
	mod_dir_path = ModLoaderMod.get_unpacked_dir().path_join(MOD_DIR)
	# Add extensions
	install_script_extensions()
	install_script_hook_files()

	# Add translations
	add_translations()
	
	InputMap.add_action("dimensionswitch");
	var ev = InputEventKey.new();
	ev.keycode = KEY_SPACE;
	ev.pressed = true;
	ev.physical_keycode = KEY_SPACE;
	InputMap.action_add_event("dimensionswitch", ev);

func install_script_extensions() -> void:
	extensions_dir_path = mod_dir_path.path_join("extensions")
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("Player.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("Play.gd"))

func install_script_hook_files() -> void:
	extensions_dir_path = mod_dir_path.path_join("extensions")

func add_translations() -> void:
	translations_dir_path = mod_dir_path.path_join("translations")

func _enter_tree() -> void:
	var lib = $"/root/ModLoader/CST1229-BALib";
	lib.add_tiles("res://mods-unpacked/CST1229-BADimensions/assets/tiles.tres");
