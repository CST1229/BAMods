extends "res://Player.gd"

var cantwarps := 0:
	set(value):
		cantwarps = value;
		var dimensions_ui = get_node_or_null("../DimensionsUI");
		if dimensions_ui:
			dimensions_ui.can_warp = cantwarps == 0;

func _on_misc_box_body_entered(body: Node2D) -> void :
	super(body);
	if body.name == "CantWarp":
		cantwarps += 1;
		
func _on_misc_box_body_exited(body: Node2D) -> void :
	super(body);
	if body.name == "CantWarp":
		cantwarps -= 1;
