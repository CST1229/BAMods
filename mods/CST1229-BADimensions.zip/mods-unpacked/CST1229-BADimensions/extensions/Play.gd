extends "res://Play.gd"

func loadlevel():
	super();
	var dimensions_ui = load("res://mods-unpacked/CST1229-BADimensions/scenes/DimensionsUI.tscn").instantiate();
	add_child(dimensions_ui);
	move_child(dimensions_ui, 0);
	dimensions_ui.initialize();
