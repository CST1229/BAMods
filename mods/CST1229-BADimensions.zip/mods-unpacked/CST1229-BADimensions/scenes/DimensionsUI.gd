extends CanvasLayer

@onready var polter: Sprite2D = $Polter
@onready var fade_player: AnimationPlayer = $FadePlayer
@onready var cantwarp_flash: AnimationPlayer = $CantwarpFlash

var can_warp := true:
	set(value):
		can_warp = value;
		if polter:
			polter.region_rect.position.x = 0 if can_warp else 16;
var alternate_dimension := false:
	set(value):
		if value != alternate_dimension:
			alternate_dimension = value;
			var pitch := 0.75 if alternate_dimension else 1.0;
			$/root/SceneManager/CanvasLayer/BGM.pitch_scale = pitch;
			$/root/SceneManager/CanvasLayer/EditorBGM.pitch_scale = pitch;

var cantwarp_tilemap;
@export var cantwarp_visible := false:
	set(value):
		cantwarp_visible = value;
		if cantwarp_tilemap:
			cantwarp_tilemap.visible = cantwarp_visible;

@onready var global = $"/root/ModLoader/CST1229-BALib".global;

func _ready() -> void:
	visible = false;

func initialize() -> void:
	var engines: TileMap = $"../Layers/Engine";
	var lib = $"/root/ModLoader/CST1229-BALib";
	var cantwarp_id = lib.tile_names_to_num["CST-blockdimenswitch"];
	var cells = engines.get_used_cells_by_id(0, cantwarp_id);
	visible = false;
	if !cells.is_empty():
		visible = true;
		cantwarp_tilemap = TileMap.new();
		cantwarp_tilemap.name = "CantWarp";
		cantwarp_visible = cantwarp_visible;
		cantwarp_tilemap.tile_set = engines.tile_set;
		cantwarp_tilemap.z_index = 5;
		for cell in cells:
			cantwarp_tilemap.set_cell(0, cell, cantwarp_id, Vector2.ZERO);
			engines.erase_cell(0, cell);
		$"../Layers".add_child(cantwarp_tilemap);

func _physics_process(delta: float) -> void:
	if visible && Input.is_action_just_pressed("dimensionswitch"):
		var player = $"../Player";
		if !player.finished && (global.playing || global.racing):
			if !can_warp:
				cantwarp_flash.play("flash");
			else:
				if enter_dimenswitch_doors():
					fade_player.stop();
					fade_player.play("switch");
					alternate_dimension = !alternate_dimension;
				else:
					$Wrong.play();
					global.notify.emit("Missing dimenswitch doors");

func enter_dimenswitch_doors() -> bool:
	var player = $"../Player";
	
	var closest_door = null
	
	var door_a = null;
	var door_b = null;
	
	var position = player.position;
	var closest_distance_a = 99999999
	var closest_distance_b = 99999999
	for i in get_tree().get_nodes_in_group("door"):
		var dist = position.distance_squared_to(i.position);
		if i.id == "dimensw1":
			if dist < closest_distance_a:
				door_a = i
				closest_distance_a = dist;
		elif i.id == "dimensw2":
			if dist < closest_distance_b:
				door_b = i
				closest_distance_b = dist;
	if !door_a || !door_b:
		return false;
	
	# swap doors so we're always travelling from door_a to door_b
	if alternate_dimension:
		var temp_door = door_b;
		door_b = door_a;
		door_a = temp_door;
	
	global.level_bgm.emit()
	var door_offset = door_b.position - door_a.position;
	player.position += door_offset;

	player.in_water_top = false
	player.in_water_bottom = false
	player.in_water = false
	
	get_parent().cameralockpos += door_offset;
	get_parent().get_node("CameraMarker").position = door_offset;
	get_parent().get_node("Camera2D").position += door_offset;
	
	var coords = str(Vector2i((door_b.position / 16).floor()));

	global.current_playing_song = global.leveldata["doors"][coords]["bgm"]
	get_parent().background = int(global.leveldata["doors"][coords]["bg"])
	get_parent().refresh_background()
	get_parent().true_void_top = global.leveldata["doors"][coords]["voidTopLevel"]
	get_parent().true_void_bottom = global.leveldata["doors"][coords]["voidBottomLevel"]
	get_parent().void_top_enabled = global.leveldata["doors"][coords]["voidTop"]
	get_parent().void_bottom_enabled = global.leveldata["doors"][coords]["voidBottom"]

	get_parent().cdseconds = int(global.leveldata["doors"][coords]["time"])
	if global.leveldata["doors"][coords]["autoTime"] == 1:
		get_parent().end_cd()
	elif global.leveldata["doors"][coords]["autoTime"] == 2:
		get_parent().secondsleft = get_parent().cdseconds
		get_parent().start_cd()
	
	get_parent().set_void_level()
	var old_y_offset = get_parent().camera_y_offset;
	var old_cam_pos = get_parent().get_node("Camera2D").position;
	return true;


func _exit_tree() -> void:
	alternate_dimension = false;
