# basically a proxy for an AudioStreamPlayer
extends Node

var player: AudioStreamPlayer;

static func hook_player(existing_player: AudioStreamPlayer):
	var hooked := new();
	hooked.player = existing_player;
	var hooked_name := existing_player.name;
	existing_player.name = hooked_name + "_Hooked";
	hooked.name = hooked_name;
	existing_player.add_sibling(hooked);
	return hooked;

func play(from_position: float = 0.0):
	player.play(from_position);
	on_play.emit(from_position);
	
signal on_play(from_position: float)
