extends "res://Play.gd"

func loadlevel():
	super();
	var lib = $"/root/ModLoader/CST1229-BALib";
	for tile_id in lib.scene_props.keys():
		var props = lib.scene_props[tile_id];
		if props.layer == "TileMap":
			for group in $Groups.get_children():
				handle_custom_tiles(tile_id, props, group, self);
		else:
			handle_custom_tiles(tile_id, props, $Layers, self);

func handle_custom_tiles(tile_id, props, group, unbound_add_to):
	var tilemap: TileMap = group.get_node(props.layer);
	for tile_pos in tilemap.get_used_cells_by_id(0, tile_id):
		var tile := tilemap.get_cell_atlas_coords(0, tile_pos);
		if tile in props.scenes:
			var alttile := tilemap.get_cell_alternative_tile(0, tile_pos) & (
				TileSetAtlasSource.TRANSFORM_FLIP_H | TileSetAtlasSource.TRANSFORM_FLIP_V |
				TileSetAtlasSource.TRANSFORM_TRANSPOSE
			);
			var instance = load(props.scenes[tile]).instantiate();
			instance.position = tilemap.map_to_local(tile_pos);
			var raw_rotation = [0, 90, 180, 270][global.rotations.find(alttile)];
			instance.rotation_degrees = raw_rotation;
			
			if "raw_position" in instance:
				instance.raw_position = tile_pos;
			if "raw_rotation" in instance:
				instance.raw_rotation = raw_rotation;
			if "tile" in instance:
				instance.tile = tile;
			if "tileset_source_id" in instance:
				instance.tileset_source_id = tile_id;
			
			if props.scene_bound_to_group[tile]:
				group.add_child(instance);
			else:
				unbound_add_to.add_child(instance);
			tilemap.erase_cell(0, tile_pos);

func refresh_background():
	super();
	if global.firstload:
		if global.leveldata.get("modded_tiles") is Dictionary:
			var lib = $"/root/ModLoader/CST1229-BALib";
			lib.convert_loaded_leveldata($Layers);
	
func finish_level():
	var lib = $"/root/ModLoader/CST1229-BALib";
	if !(global.playing_online_level or global.playing_story_level) or !lib._uploads_disabled:
		super();
		return;
	
	pressedfinish = true
	if global.practice_mode:
		restart_level(true)
	else:
		if global.playing_story_level:
			open_world_map()
			global.notify.emit("Level completions disabled by " + lib._uploads_disabled);
		else:
			global.scene.emit("res://Title.tscn")
			global.notify.emit("Level completions disabled by " + lib._uploads_disabled);
