extends "res://keybinds.gd"

var added_keys: Dictionary = {};

func _ready():
	super();
	
	var left_key = $Keys/left;
	
	$PressAnyKey.position.y = 278;
	($PressAnyKey as Label).horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT;
	($PressAnyKey as Label).size.x = 735;
	var scroller := ScrollContainer.new();
	scroller.position = Vector2(11, 9);
	scroller.size = Vector2(410, 300);
	add_child(scroller);
	move_child(scroller, 0);
	var keys = $Keys;
	keys.reparent(scroller);
	
	var lib = $"/root/ModLoader/CST1229-BALib";
	for key in lib.custom_keys.keys():
		var button = left_key.duplicate();
		button.name = key;
		button.get_node("Label").text = lib.custom_keys[key];
		button.button_down.connect(_on_button_pressed.bind(button))
		button.text = global.get_key_name(key);
		added_keys[button] = key;
		keys.add_child(button);

func _update_labels() -> void:
	super();
	for button in added_keys.keys():
		button.text = global.get_key_name(added_keys[button]);
