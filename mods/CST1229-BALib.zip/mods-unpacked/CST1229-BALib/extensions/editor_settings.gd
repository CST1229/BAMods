extends "res://editor_settings.gd"

func _ready():
	super();
	var lib = $"/root/ModLoader/CST1229-BALib";
	var not_tilemap = load("res://mods-unpacked/CST1229-BALib/NotTileMap.gd").new();
	not_tilemap.name = "ModdedTilesHook";
	not_tilemap.on_get_used_cells.connect(func():
		structuredata.erase("modded_tiles");
		lib.deconvert_loaded_leveldata(structuredata);
	);
	$"../../CopyLayer".add_child(not_tilemap);

func _physics_process(delta: float) -> void :
	if Input.is_action_just_pressed("click"):
		if category == 1:
			for i in $"Menu/Panel/Categories/1/ScrollContainer/Structures".get_children():
				if i.get_node("Main").button_pressed:
					$"../../Sounds/Click".play()
					for l in $"../../CopyLayer".get_children():
						for t in l.get_used_cells(0):
							l.set_cell(0, t, -1)
					var file = FileAccess.open(str("user://structures/", i.strcname, ".strc"), FileAccess.READ)
					var content = JSON.parse_string(file.get_as_text())
					if !content.has("Camera2"):
						content["Camera2"] = ""
					if !content.has("Camera3"):
						content["Camera3"] = ""
					if !content.has("Camera4"):
						content["Camera4"] = ""
					if !content.has("Key"):
						content["Key"] = ""
					if !content.has("Engine"):
						content["Engine"] = ""
					if !content.has("Guide"):
						content["Guide"] = ""
					var lib = $"/root/ModLoader/CST1229-BALib";
					lib.convert_loaded_leveldata($"../../CopyLayer", content);
					for l in $"../../CopyLayer".get_children():
						var tilearray = []
						if l.name != "Temp" && l.name in content:
							for t in content[str(l.name)].split("/"):
								var currenttile = t.split(",")
								if currenttile.size() == 5:

									l.set_cell(0, Vector2i(int(currenttile[1]), int(currenttile[2])), int(currenttile[0]), Vector2i(int(currenttile[3]), 0), global.rotations[int(currenttile[4])])
									tilearray.append(Vector2i(int(currenttile[1]), int(currenttile[2])))
							if tilearray.size() > 0:
								BetterTerrain.update_terrain_cells(l, 0, tilearray)
					global.notify.emit(str("Loaded ", i.strcname))
					$"../..".pasted_from_structure = true
					return;
	super(delta);

func infobox_input(id, value):
	super(id, value);
	if id == "reseteditorkeybinds" and value == 1:
		var lib = $"/root/ModLoader/CST1229-BALib";
		for key in lib.editor_keys.keys():
			global.settings["editorkeybinds"][key] = lib.key_defaults[key];
			var key_event = InputEventKey.new()
			key_event.keycode = lib.key_defaults[key];
			key_event.pressed = true;
			InputMap.action_erase_events(key)
			InputMap.action_add_event(key, key_event)
		$"Menu/Panel/Categories/5/ScrollContainer/Keybinds"._update_labels()
