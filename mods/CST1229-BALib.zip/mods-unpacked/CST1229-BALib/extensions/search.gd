extends "res://search.gd"

@onready var balib_lib = $"/root/ModLoader/CST1229-BALib";

func fix_classic_mode():
	super();
	var gc = $Menu/Panel/ScrollContainer/GridContainer;
	var visible_children := 0;
	for child in gc.get_children():
		if child.visible:
			visible_children += 1;
	gc.custom_minimum_size.y = 70 * ceilf(float(visible_children) / float(gc.columns));

func get_object(i, c):
	var tile_id = i.id;
	if i.id in balib_lib.tile_props:
		var props = balib_lib.tile_props[i.id];
		$"../..".layer = props.layer;
		$"../..".change_category(props.editor_category)
		global.tileselected[props.layer] = i.id
		global.color = i.color
		return;
	super(i, c);
