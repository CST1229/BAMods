extends "res://group.gd"

const TRANSFORM_MASK = TileSetAtlasSource.TRANSFORM_FLIP_H | TileSetAtlasSource.TRANSFORM_FLIP_V | TileSetAtlasSource.TRANSFORM_TRANSPOSE;

func shade():
	super();
	var lib = $"/root/ModLoader/CST1229-BALib";
	var play := $"../..";
	var rotated_layers: Array[TileMap] = [$RotatedLayers/TileMapRight, $RotatedLayers/TileMapDown, $RotatedLayers/TileMapLeft];
	for tile_id in lib.tile_props.keys():
		var props: Dictionary = lib.tile_props[tile_id];
		if !props.special_processing || props.is_scene:
			continue;
		var layer := get_regular_tile_layer(props.layer);
		if !layer:
			continue;
		for tile in layer.get_used_cells_by_id(0, tile_id):
			var coords := layer.get_cell_atlas_coords(0, tile);
			if coords in props.custom_tilemap:
				var alttile := layer.get_cell_alternative_tile(0, tile);
				get_custom_tile_layer(props.custom_tilemap[coords]).set_cell(0, tile, tile_id, coords, alttile);
				layer.set_cell(0, tile, -1);
		if props.layer == "TileMap" && props.rotatable != "none":
			# copy and pasted code aaargh
			layer = $RotatedLayers/TileMapRight;
			for tile in layer.get_used_cells_by_id(0, tile_id):
				var coords := layer.get_cell_atlas_coords(0, tile);
				if coords in props.custom_tilemap:
					var alttile := (layer.get_cell_alternative_tile(0, tile) & ~TRANSFORM_MASK) | (global.rotations[1] as int);
					get_custom_tile_layer(props.custom_tilemap[coords]).set_cell(0, Vector2(-tile.y, tile.x), tile_id, coords, alttile);
					layer.set_cell(0, tile, -1);
			layer = $RotatedLayers/TileMapDown;
			for tile in layer.get_used_cells_by_id(0, tile_id):
				var coords := layer.get_cell_atlas_coords(0, tile);
				if coords in props.custom_tilemap:
					var alttile := (layer.get_cell_alternative_tile(0, tile) & ~TRANSFORM_MASK) | (global.rotations[2] as int);
					get_custom_tile_layer(props.custom_tilemap[coords]).set_cell(0, Vector2(-tile.x, -tile.y), tile_id, coords, alttile);
					layer.set_cell(0, tile, -1);
			layer = $RotatedLayers/TileMapLeft;
			for tile in layer.get_used_cells_by_id(0, tile_id):
				var coords := layer.get_cell_atlas_coords(0, tile);
				if coords in props.custom_tilemap:
					var alttile := (layer.get_cell_alternative_tile(0, tile) & ~TRANSFORM_MASK) | (global.rotations[3] as int);
					get_custom_tile_layer(props.custom_tilemap[coords]).set_cell(0, Vector2(tile.y, -tile.x), tile_id, coords, alttile);
					layer.set_cell(0, tile, -1);
				

func get_regular_tile_layer(layer_name: String) -> TileMap:
	var layer := get_node_or_null(layer_name) as TileMap;
	if !layer:
		layer = $"../..".get_node_or_null(layer_name) as TileMap;
	return layer;

func get_custom_tile_layer(layer_name: String) -> TileMap:
	var layer := get_node_or_null(layer_name) as TileMap;
	if !layer:
		layer = TileMap.new();
		layer.name = layer_name;
		layer.tile_set = $SpikeBlock.tile_set;
		layer.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST;
		add_child(layer);
	return layer;
