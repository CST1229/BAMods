extends "res://SettingsLayer.gd"

var did_check_invalid_objects := false;

func _physics_process(delta: float) -> void :
	did_check_invalid_objects = false;
	if global.editorsettings == true:
		if Input.is_action_just_pressed("click") && category == 2:
			if $"Menu/Panel/Categories/2/PublishButton".button_pressed:
				var did_stuff := check_invalid_objects();
				if did_stuff:
					$"Menu/Panel/Categories/2/PublishButton".button_pressed = false;
					$"../../Sounds/Click".play();
					# prevent the vanilla publish button code from running
					return;
	super(delta);

func publish_level():
	if check_invalid_objects():
		return;
	super();

func check_invalid_objects() -> bool:
	if did_check_invalid_objects:
		return false;
	did_check_invalid_objects = true;
	return do_check_invalid_objects();
	
func do_check_invalid_objects() -> bool:
	var lib = $"/root/ModLoader/CST1229-BALib";
	if lib._uploads_disabled:
		global.notify.emit("Uploads disabled by " + lib._uploads_disabled);
		return true;
	
	var bgm = global.leveldata["bgm"];
	if bgm in lib.custom_songs:
		global.notify.emit("Levels containing modded songs cannot be uploaded\n(%s)" % [bgm]);
		return true;
	
	var layers := $"../../Layers";
	for tile_id in lib.tile_props.keys():
		for layer: TileMap in layers.get_children():
			var used_tiles = layer.get_used_cells_by_id(0, tile_id);
			if !used_tiles.is_empty():
				global.notify.emit("Levels containing modded tiles cannot be uploaded\n(%s found at %s)" % [lib.tile_nums_to_name[tile_id], used_tiles[0]]);
				return true;
	return false;
