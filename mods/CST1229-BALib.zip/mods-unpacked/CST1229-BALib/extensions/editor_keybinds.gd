extends "res://editor_keybinds.gd"

func _ready():
	var lib = $"/root/ModLoader/CST1229-BALib";
	for key in lib.editor_keys.keys():
		keys[key] = lib.editor_keys[key];
		custom_minimum_size.y += 30;
	super();
