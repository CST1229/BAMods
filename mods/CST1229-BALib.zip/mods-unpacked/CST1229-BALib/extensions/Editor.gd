extends "res://Editor.gd"

@onready var balib_lib = $"/root/ModLoader/CST1229-BALib";

func _ready():	
	var _global = $/root/SceneManager/global;
	super();
	
	var hooked_player = load("res://mods-unpacked/CST1229-BALib/NotAudioStreamPlayer.gd").hook_player($Sounds/Select);
	hooked_player.on_play.connect(_on_select_play);

func _physics_process(delta: float):
	var old_settingthumbnail = settingthumbnail;
	super(delta);
	if old_settingthumbnail && !settingthumbnail && Input.is_action_just_released("editor_thumbnail") && "thumbnail" in global.leveldata:
		# convert thumbnails
		var parsed = JSON.parse_string(global.leveldata["thumbnail"]);
		for layer in balib_lib.all_layers:
			if layer in parsed:
				var arr := (parsed[layer] as String).split("/");
				for tile in arr:
					if tile != "":
						var parsed_tile := (tile as String).split(",");
						var tileid := int(parsed_tile[0]);
						if tileid in balib_lib.tile_nums_to_name:
							if "modded_tiles" not in parsed:
								parsed.modded_tiles = {};
							parsed.modded_tiles[tileid] = balib_lib.tile_nums_to_name[tileid];
		if "modded_tiles" in parsed:
			global.leveldata.thumbnail = JSON.stringify(parsed);
		
	

func change_rotation():
	super();
	if global.tileselected[layer] in balib_lib.tile_props:
		match balib_lib.tile_props[global.tileselected[layer]].rotatable:
			"flip":
				if global.rotation == 1:
					global.rotation = 2
				elif global.rotation == 3:
					global.rotation = 0
			"90deg":
				if global.rotation == 2:
					global.rotation = 0
				elif global.rotation == 3:
					global.rotation = 1

func savelevel():
	super();
	global.leveldata.erase("modded_tiles");
	for l in $Layers.get_children():
		var cells := (l as TileMap).get_used_cells(0);
		for i in cells:
			var tileid = l.get_cell_source_id(0, i);
			if tileid in balib_lib.tile_nums_to_name:
				if "modded_tiles" not in global.leveldata:
					global.leveldata.modded_tiles = {};
				global.leveldata.modded_tiles[str(tileid)] = balib_lib.tile_nums_to_name[tileid];
	global.levelcode = JSON.stringify(global.leveldata)
	$"Camera2D/SettingsLayer/Menu/Panel/Categories/0/Size".text = str(snapped(global.levelcode.length() / 1000.0, 0.1), " KB")

func load_artboards():
	balib_lib.convert_loaded_leveldata($Layers);
	super();

func refresh_objects():
	super();
	if global.practice_point_editor:
		return;
	# handle custom objects specially since they can be put into any category
	# instead of basing it on their layer
	var objects = $Camera2D/CanvasLayer/ScrollContainer/Objects;
	for tile_id in balib_lib.tile_props:
		var props = balib_lib.tile_props[tile_id];
		if props.editor_category:
			var button = objects.get_node_or_null(str(tile_id));
			if button:
				button.visible = category == props.editor_category;

# fix modded tiles in favorites
func save_favorites():
	for fave_arr in global.favorites.values():
		for fave in fave_arr: 
			if fave[0] in balib_lib.tile_nums_to_name:
				var dict;
				if fave.size() > 2:
					if fave[-1] is Dictionary:
						dict = fave[-1];
					else:
						continue;
				else:
					dict = {};
					fave.append(dict);
				fave[-1].balib_modded_tile = balib_lib.tile_nums_to_name[fave[0]];
				# set the vanilla tile to the Temporary Toggle Block for if the mod is disabled
				# this shows a checker texture
				fave[0] = 25;
	super();
	# fix favorites again
	balib_lib.fix_favorites();

# hacky stuff to allow selecting any layer tile in any category
var stored_layer := "";
const FAKE_LAYER = "_selected_custom_tile";
func update_preview(categorymode: bool = false):
	super(categorymode);
	if stored_layer != "":
		global.tileselected.erase(layer);
		layer = stored_layer;
		stored_layer = "";

func _on_select_play(_from: float):
	var clicked_tile: TextureButton = null;
	for i in $Camera2D / CanvasLayer / ScrollContainer / Objects.get_children():
		if i.button_pressed:
			clicked_tile = i;
			break;
	if !clicked_tile:
		return;
	var tile_id := int(str(clicked_tile.name));
	if tile_id in balib_lib.tile_props:
		global.tileselected[FAKE_LAYER] = tile_id;
		stored_layer = balib_lib.tile_props[tile_id].layer;
		global.tileselected[stored_layer] = tile_id;
		layer = FAKE_LAYER;
	
