# basically a not-proxy for an TileMap
extends Node

func get_used_cells(_layer):
	on_get_used_cells.emit();
	return [];

signal on_get_used_cells()
