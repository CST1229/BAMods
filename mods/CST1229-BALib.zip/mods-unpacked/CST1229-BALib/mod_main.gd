class_name BALib
extends Node

## Library mod for BA-related stuff.
##
## [b]How to use[/b]: Add this in your mod's _enter_tree function:
## [codeblock]var lib = $"/root/ModLoader/CST1229-BALib";[/codeblock]
## Then you can call functions on it. Functions that add content, like [method add_tiles], MUST be called in [method Node._enter_tree] for them to work!
## [br]If you don't need to use the content adding functions though, you can also add it into [method Node._ready] or as an [code]@onready[/code] variable declaration.

const _MOD_DIR := "CST1229-BALib"; # Name of the directory that this file is in
const _LOG_NAME := "CST1229-BALib:Main"; # Full ID of the mod (AuthorName-ModName)

## A reference to the global singleton. Only available after _ready (and you might want to get it yourself too).
@onready var global := $/root/SceneManager/global;

## Every tile layer name in an array.
var all_layers: Array[String] = ["TileMap", "Decoration", "Wall", "Camera", "Camera2", "Camera3", "Camera4", "CameraOffset", "Key", "Engine", "Guide"];

var mod_dir_path := "";
var extensions_dir_path := "";

var _uploads_disabled := "";

var _readied_up := false;

## Disables level uploads and completions. Your mod ID or name should be in [param mod] so players know which mod to disable.
func disable_uploads(mod: String):
	if !_uploads_disabled:
		_uploads_disabled = mod;
		ModLoaderLog.info("Uploads disabled: " + mod, _LOG_NAME);

## Every custom song (and their credit).
var custom_songs := {};
var _custom_song_assets := [];
## Adds a custom song. If [param editor_path] is not present, uses [param path] as the editor song.
func add_song(path: String, song_name: String, credit: String, editor_path: String = path) -> void:
	if _readied_up:
		ModLoaderLog.error("add_song must be called in _enter_tree - song_name: " + song_name, _LOG_NAME);
		return;
	if song_name in custom_songs:
		ModLoaderLog.error("Song " + name + " already exists", _LOG_NAME);
		return;
	
	var song_asset = load(path);
	var editor_asset = load(editor_path);
	if path == editor_path:
		editor_asset = song_asset.duplicate();
	song_asset.take_over_path("res://assets/songs/level/" + song_name + ".ogg");
	editor_asset.take_over_path("res://assets/songs/editor/" + song_name + ".ogg");
	_custom_song_assets.append(song_asset);
	_custom_song_assets.append(editor_asset);
	
	ModLoaderLog.info("Added song: " + song_name, _LOG_NAME);
	
	custom_songs[song_name] = credit;

var _tilesets_to_add := PackedStringArray();
## Mapping of numerical tile IDs to modded tile names.
var tile_nums_to_name := {};
## Mapping of modded tile names to numerical tile IDs.
var tile_names_to_num := {};
## Mapping of numerical tile IDs to tile properties.
var tile_props := {};
## Every custom scene tile (numerical ID) and their tile_props properties.
var scene_props := {};

## Every possible value for the [code]editor_category[/code] of a tile.
const modded_editor_categories = {
	"terrain": "Terrain",
	"hazards": "Hazards",
	"misc": "Misc",
	"gizmos": "Misc",
	"items": "Items",
	"decoration": "Decoration",
	"deco": "Deco",
	"walls": "Wall",
	"wall": "Wall",
	"camera": "Camera",
	"engine": "Engine",
	"engines": "Engine",
};

## Adds custom tiles from a [TileSet] at [param path]. This tileset must contain [b]only[/b] your added tiles.
## [br][br]
## Each [TileSetAtlasSource] in the tile set is treated as a single tile ID.
## The atlas' name is treated as the tile's unique text-based ID (in order to prevent numerical ID shifts). [b]Filling in a name is required![/b] (You must also not change this, otherwise existing levels will break.)
## [br]Physics layers are transferred; you can use the vanilla Tileset.tres for reference. Regular solid tiles have layers 1, 2, 3, 25 and 26 selected in both the collision layer and mask.
## [br]Multiple tiles in one atlas are treated as variations (cycled with the [kbd]C[/kbd] key in the editor).
## [TileSetScenesCollectionSource]s are not supported. Alternative tiles are also not supported.
## [br][br]Custom data layers can be used to customize tiles. For all properties except [code]name[/code] and [code]scene_or_layer[/code], only the first tile's data is read, and is applied to all variations.
## [br]You may duplicate [code]res://mods-unpacked/CST1229-BALib/tileset_template.tres[/code] for an example. This resource has all needed custom data layers, and 2 example physics layers (layer 0 for solid tiles and layer 1 for miscellaneous tiles like rays).
## [br]- [code]name[/code]: The name of the tile that shows up in the editor. Can be customized per-variation.
## [br]- [code]scene_or_layer[/code]: A custom scene this tile spawns OR a custom tilemap name this tile is put into (useful for creating custom rays). Can be customized per-variation.
## [br]- [code]scene_bound_to_group[/code]: If this tile is a custom scene and if this value is true, the tile's scene instances will be bound to the engine group they're a part of (for e.g scenes that behave like tiles). Otherwise, they will move independently from it.
## [br]- [code]rotatable[/code]: The rotation behavior of this tile ([kbd]R[/kbd] key). Valid values: [code]none[/code] (default), [code]all[/code], [code]flip[/code], [code]90deg[/code].
## [br]    - Diagonal rotations (like the diagonal arrows) require 2 separate tile IDs: the orthogonal tile needs a rotation style of [code]diagonal:DIAGONAL_TILE_ID[/code], and the diagonal tile needs a rotation style of [code]orthogonal:ORTHOGONAL_TILE_ID[/code].
## [br]- [code]layer[/code]: Which tile map layer this tile is on. Valid values: [code]TileMap[/code] (default; terrain), [code]Decoration[/code], [code]Wall[/code], [code]Camera[/code] (horizontal), [code]Camera2[/code] (vertical), [code]Camera3[/code] (zoom), [code]Key[/code], [code]Engine[/code], [code]Guide[/code].
## [br]- [code]shaded[/code]: If true, this tile casts a shadow.
## [br]- [code]editor_category[/code]: The name of the editor category this tile resides in. Case-insensitive. If empty, the tile is hidden from the editor, but if absent, it's put into the Terrain tab.
## [br][br]Custom scene tiles get their [member Node2D.position] and [member Node2D.rotation] set to their position/rotation in the tilemap.
## [br]They can also get the following properties set if they're present:
## [br]- [code]raw_position[/code] ([Vector2i]): The raw position of the original tile.
## [br]- [code]raw_rotation[/code] ([int]): The raw rotation of the original tile (0-3, as in global.rotations).
## [br]- [code]tile[/code] ([Vector2i]): The position of the original tile in its atlas. Its X value is the tile's variant/color.
## [br]- [code]tileset_source_id[/code] ([int]): The numerical tile ID that spawned this scene, in case you want to assign the same scene to two different tiles I guess.
func add_tiles(path: String) -> void:
	if _readied_up:
		ModLoaderLog.error("add_tiles must be called in _enter_tree - tileset path: " + path, _LOG_NAME);
		return;
	_tilesets_to_add.append(path);

## Converts all modded tiles in [code]global.leveldata[/code] to be loadable, given a node that contains all layers.
func convert_loaded_leveldata(layers: Node, leveldata: Dictionary = global.leveldata) -> void:
	if !layers:
		return;
	if "modded_tiles" not in leveldata:
		return;
	for l in layers.get_children():
		var layer_name = l.name;
		if layer_name in leveldata:
			leveldata[layer_name] = convert_modded_tiles(leveldata[layer_name], leveldata.modded_tiles);

## Converts a raw loaded tile dictionary in-place to use modded_tiles.
func deconvert_loaded_leveldata(dict: Dictionary) -> void:
	var modded_tiles = {};
	for l in all_layers:
		if l in dict:
			deconvert_modded_tiles(dict[l], modded_tiles);
	if modded_tiles.size() > 0:
		dict.modded_tiles = modded_tiles;

## Converts a stored tile layer code [param data] to use current tile IDs instead of the ones specified in the level ([param modded_tiles]).
func convert_modded_tiles(data: String, modded_tiles: Dictionary) -> String:
	var split := data.split("/");
	var unknown_tiles := PackedStringArray();
	for i in range(split.size()):
		var comma_index := split[i].find(",");
		var tile_id := split[i].substr(0, comma_index);
		if tile_id in modded_tiles:
			if modded_tiles[tile_id] not in tile_names_to_num:
				var id = str(modded_tiles[tile_id]);
				ModLoaderLog.error("Custom tile not found: " + id, _LOG_NAME);
				if id not in unknown_tiles:
					unknown_tiles.append(id);
				continue;
			split[i] = str(tile_names_to_num[modded_tiles[tile_id]]) + split[i].substr(comma_index);
	if !unknown_tiles.is_empty():
		global.notify.emit("Found unknown modded tiles:\n" + ", ".join(unknown_tiles))
	return "/".join(split);

## Adds the required modded_tiles from stored tile layer code [param data].
func deconvert_modded_tiles(data: String, modded_tiles: Dictionary) -> void:
	var split := data.split("/");
	for i in range(split.size()):
		var comma_index := split[i].find(",");
		var tile_id := split[i].substr(0, comma_index);
		if tile_id in tile_nums_to_name or int(tile_id) in tile_nums_to_name:
			modded_tiles[tile_id] = tile_nums_to_name[int(tile_id)];


func _do_add_tiles() -> void:
	if _tilesets_to_add.is_empty():
		return
	var vanilla_tiles: TileSet = load("res://Tileset.tres");
	for path: String in _tilesets_to_add:
		var tileset: TileSet = load(path);
		_do_add_tileset(tileset, vanilla_tiles);
	vanilla_tiles.take_over_path(vanilla_tiles.resource_path);
	
	# fix up diagonals
	for tile_id in global.diagonals.keys():
		if global.diagonals[tile_id] is String:
			global.diagonals[tile_id] = tile_names_to_num[global.diagonals[tile_id]];
	for tile_id in global.diagonals_reverse.keys():
		if global.diagonals_reverse[tile_id] is String:
			global.diagonals_reverse[tile_id] = tile_names_to_num[global.diagonals_reverse[tile_id]];

func _do_add_tileset(tileset: TileSet, vanilla_tiles: TileSet) -> void:
	var vanilla_layers_by_id := {};
	for layer in range(vanilla_tiles.get_physics_layers_count()):
		vanilla_layers_by_id[_get_physics_layer_id(vanilla_tiles, layer)] = layer;
	
	var datalayer_name := tileset.get_custom_data_layer_by_name("name");
	var datalayer_rotatable := tileset.get_custom_data_layer_by_name("rotatable");
	var datalayer_layer := tileset.get_custom_data_layer_by_name("layer");
	var datalayer_shaded := tileset.get_custom_data_layer_by_name("shaded");
	var datalayer_editor_category := tileset.get_custom_data_layer_by_name("editor_category");
	var datalayer_scene_or_layer := tileset.get_custom_data_layer_by_name("scene_or_layer");
	var datalayer_scene_bound_to_group := tileset.get_custom_data_layer_by_name("scene_bound_to_group");
	
	# add physics layers that aren't already present
	var physics_layer_map := PackedInt32Array();
	physics_layer_map.resize(tileset.get_physics_layers_count());
	for layer in range(tileset.get_physics_layers_count()):
		var layer_id := _get_physics_layer_id(tileset, layer);
		if layer_id not in vanilla_layers_by_id:
			var new_layer := vanilla_tiles.get_physics_layers_count();
			vanilla_tiles.add_physics_layer();
			vanilla_tiles.set_physics_layer_collision_layer(new_layer, tileset.get_physics_layer_collision_layer(layer));
			vanilla_tiles.set_physics_layer_collision_mask(new_layer, tileset.get_physics_layer_collision_mask(layer));
			vanilla_tiles.set_physics_layer_physics_material(new_layer, tileset.get_physics_layer_physics_material(layer));
			vanilla_layers_by_id[layer_id] = new_layer;
		physics_layer_map[layer] = vanilla_layers_by_id[layer_id];
	
	for src_index in range(tileset.get_source_count()):
		var src_id := tileset.get_source_id(src_index);
		var src_any := tileset.get_source(src_id);
		if src_any is not TileSetAtlasSource:
			ModLoaderLog.warning(
				"In custom tileset %s: Source %s is not an atlas. Only atlases are supported. Skipping." % [tileset.resource_path, (src_any.resource_name + " (ID " + str(src_id) + ")") if src_any.resource_name else str(src_id)],
				_LOG_NAME
			);
			continue;
		var src := src_any as TileSetAtlasSource;
		if !src.resource_name:
			ModLoaderLog.error(
				"In custom tileset %s: Source ID %s has no name! Skipping." % [tileset.resource_path, src_id],
				_LOG_NAME
			);
			continue;
		if src.get_tiles_count() == 0:
			ModLoaderLog.error(
				"In custom tileset %s: Source ID %s has no tiles! Skipping." % [tileset.resource_path, src_id],
				_LOG_NAME
			);
			continue;
		
		var modded_id := src.resource_name;
		
		var names := [];
		var new_id := vanilla_tiles.add_source(src.duplicate());
		var vanilla_src := vanilla_tiles.get_source(new_id) as TileSetAtlasSource;
		
		var props := {};
		props.custom_tilemap = {};
		props.special_processing = false;
		props.scenes = {};
		props.scene_bound_to_group = {};
		
		for tile_index in vanilla_src.get_tiles_count():
			var tile_pos := vanilla_src.get_tile_id(tile_index);
			var tile_data := vanilla_src.get_tile_data(tile_pos, 0);
			var old_tile_data := src.get_tile_data(tile_pos, 0);
			
			# just throw out all physics layer data and port it over from the old tile data
			for layer in range(vanilla_tiles.get_physics_layers_count()):
				tile_data.set_constant_angular_velocity(layer, 0);
				tile_data.set_constant_linear_velocity(layer, Vector2.ZERO);
				for poly in range(tile_data.get_collision_polygons_count(layer)):
					tile_data.remove_collision_polygon(layer, 0);
			for layer in range(tileset.get_physics_layers_count()):
				var new_layer := physics_layer_map[layer];
				tile_data.set_constant_angular_velocity(new_layer, old_tile_data.get_constant_angular_velocity(layer));
				tile_data.set_constant_linear_velocity(new_layer, old_tile_data.get_constant_linear_velocity(layer));
				
				for poly in range(old_tile_data.get_collision_polygons_count(layer)):
					var points := old_tile_data.get_collision_polygon_points(layer, poly);
					var one_way := old_tile_data.is_collision_polygon_one_way(layer, poly);
					var margin := old_tile_data.get_collision_polygon_one_way_margin(layer, poly);
										
					var new_poly := tile_data.get_collision_polygons_count(new_layer);
					tile_data.add_collision_polygon(new_layer);
					tile_data.set_collision_polygon_one_way(new_layer, new_poly, one_way);
					tile_data.set_collision_polygon_one_way_margin(new_layer, new_poly, margin);
					tile_data.set_collision_polygon_points(new_layer, new_poly, points);
			
			# apply tile properties if present
			if datalayer_name > -1:
				names.append(str(old_tile_data.get_custom_data_by_layer_id(datalayer_name)));
			else:
				names.append(modded_id);
			if datalayer_scene_or_layer > -1:
				var scene_or_layer := str(old_tile_data.get_custom_data_by_layer_id(datalayer_scene_or_layer));
				props.is_scene = true;
				if scene_or_layer != "" && scene_or_layer != "<null>":
					props.special_processing = true;
					if scene_or_layer.begins_with("res://"):
						scene_props[new_id] = props;
						props.scenes[tile_pos] = scene_or_layer;
					else:
						props.custom_tilemap[tile_pos] = scene_or_layer;
			props.scene_bound_to_group[tile_pos] = false;
			if datalayer_scene_bound_to_group > -1:
				var bound_to_group := bool(old_tile_data.get_custom_data_by_layer_id(datalayer_scene_bound_to_group));
				if bound_to_group:
					props.scene_bound_to_group[tile_pos] = true;
			
			if tile_index == 0:
				if datalayer_rotatable > -1:
					props.rotatable = str(old_tile_data.get_custom_data_by_layer_id(datalayer_rotatable));
					if !props.rotatable || props.rotatable == "<null>":
						props.rotatable = "none";
					if props.rotatable != "none":
						global.rotatable.append(new_id);
						if props.rotatable.begins_with("diagonal:"):
							var rotated_id = props.rotatable.substr("diagonal:".length());
							global.diagonals[new_id] = rotated_id;
						elif props.rotatable.begins_with("orthogonal:"):
							var rotated_id = props.rotatable.substr("orthogonal:".length());
							global.diagonals_reverse[new_id] = rotated_id;
				else:
					props.rotatable = "none";
				if datalayer_layer > -1:
					props.layer = str(old_tile_data.get_custom_data_by_layer_id(datalayer_layer));
					if !props.layer || props.layer == "<null>":
						props.layer = "TileMap";
				else:
					props.layer = "TileMap";
				global.objectlayers[props.layer].append(new_id);
				if datalayer_shaded > -1 && old_tile_data.get_custom_data_by_layer_id(datalayer_shaded):
					global.shadedtiles.append(new_id);
				if datalayer_editor_category > -1:
					props.editor_category = str(old_tile_data.get_custom_data_by_layer_id(datalayer_editor_category)).to_lower();
					if props.editor_category in modded_editor_categories:
						props.editor_category = modded_editor_categories[props.editor_category];
					else:
						props.editor_category = "";
				else:
					props.editor_category = "Terrain";
				if props.editor_category in global.tilemapcategories:
					global.tilemapcategories[props.editor_category].append(new_id);
		tile_props[new_id] = props;
		
		if names.size() == 1:
			global.tilenames.append(names[0]);
		else:
			global.tilenames.append(names);
		global.variations.append(vanilla_src.get_tiles_count());
		tile_names_to_num[modded_id] = new_id;
		tile_nums_to_name[new_id] = modded_id;
		
		ModLoaderLog.info("Added tile: " + modded_id + " (" + ", ".join(names) + ")", _LOG_NAME);

func _get_physics_layer_id(tileset: TileSet, layer: int) -> String:
	var collision_layer := tileset.get_physics_layer_collision_layer(layer);
	var collision_mask := tileset.get_physics_layer_collision_mask(layer);
	var material := tileset.get_physics_layer_physics_material(layer);
	return "%s-%s-%s" % [collision_layer, collision_mask, material];


var custom_keys := {};
var editor_keys := {};
var key_defaults := {};

## Adds a custom keybind.
func add_keybind(action_name: StringName, title: String, default_keyboard: Key = KEY_NONE, default_controller: JoyButton = JOY_BUTTON_INVALID, is_editor: bool = false):
	if InputMap.has_action(action_name):
		ModLoaderLog.error("Custom keybind action already exists: " + action_name, _LOG_NAME);
		return;
	
	InputMap.add_action(action_name);
	key_defaults[action_name] = default_keyboard;
	if default_keyboard > 0:
		var ev := InputEventKey.new();
		ev.keycode = default_keyboard;
		ev.pressed = true;
		InputMap.action_add_event(action_name, ev);
	var controller_action_name := "controller_" + action_name;
	InputMap.add_action(controller_action_name);
	if default_controller >= 0:
		var ev := InputEventJoypadButton.new();
		ev.button_index = default_controller;
		ev.pressed = true;
		InputMap.action_add_event(controller_action_name, ev);
	
	if is_editor:
		editor_keys[action_name] = title;
	else:
		custom_keys[action_name] = title;

func _init() -> void:
	ModLoaderLog.info("Init", _LOG_NAME);
	mod_dir_path = ModLoaderMod.get_unpacked_dir().path_join(_MOD_DIR);
	
	if !OS.has_feature("editor") && !DirAccess.dir_exists_absolute("res://assets/songs/level"):
		var success = ProjectSettings.load_resource_pack("songs.pck")
		if !success:
			success = ProjectSettings.load_resource_pack("user://songs.pck")
	
	var _global = load("res://global.gd").new();
	var version: String = _global.version;
	_global.free();
	ModLoaderStore.ml_options.semantic_version = version.replacen("Beta", "").replacen("Alpha", "").replace(" ", "");
	
	_install_script_extensions();

func _install_script_extensions() -> void:
	extensions_dir_path = mod_dir_path.path_join("extensions")
	
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("search.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("Editor.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("group.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("Play.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("SettingsLayer.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("editor_settings.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("keybinds.gd"))
	ModLoaderMod.install_script_extension(extensions_dir_path.path_join("editor_keybinds.gd"))

func fix_favorites():
	# fix modded tiles in favorites
	for fave_arr in global.favorites.values():
		var i = 0;
		for fave in fave_arr.duplicate():
			i += 1;
			if fave is not Array:
				fave_arr.erase(i);
				i -= 1;
			elif fave.size() > 2 && fave[-1] is Dictionary && "balib_modded_tile" in fave[-1]:
				var id = fave[-1].balib_modded_tile;
				if id in tile_names_to_num:
					fave[0] = tile_names_to_num[id];
				else:
					ModLoaderLog.error("Favorited custom tile not found: " + id, _LOG_NAME);

func _ready() -> void:
	ModLoaderLog.info("Ready", _LOG_NAME);
	if global:
		(global.songcredits as Dictionary).merge(custom_songs, true);
		_do_add_tiles.call_deferred();
		fix_favorites.call_deferred();
	_readied_up = true;
